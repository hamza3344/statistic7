﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statistics7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] valuesx = textBox1.Text.Split(",");
            string[] valuesy = textBox2.Text.Split(",");
            int n = valuesx.Length;
            double Exy = 0;
            double Ex = 0;
            double Ey = 0;
            double Exsquare = 0;
            double Eysquare = 0;
            int i=0;
            foreach(string s in valuesx)
            {
                Exy = Exy + (double.Parse(s) * double.Parse(valuesy[i]));
                Ex = Ex + double.Parse(s);
                Ey = Ey + double.Parse(valuesy[i]);
                Exsquare = Exsquare + Math.Pow(double.Parse(s), 2);
                Eysquare = Eysquare + Math.Pow(double.Parse(valuesy[i]), 2);
                i = i + 1;
            }
            double r = ((n*Exy)-(Ex*Ey)) / Math.Sqrt(((n*Exsquare)-Math.Pow(Ex,2))*((n * Eysquare) - Math.Pow(Ey, 2)));
            MessageBox.Show(r.ToString());
        }
    }
}
